# Volleyball Scoresheet v21

Digital volleyball scoring app that produces a printable NCAA scoresheet that looks hand-completed.

## What's new in v21
- **Realistic printable scoresheet.** Every set is drawn in blue "pen" ink on the actual NCAA form: header info with the day and A.M./P.M. circled, team names, liberos, starting lineup (captain circled), substitutes with entry score, a full service record on each service-order line (circled point numbers, R for rotate, plain numbers for points earned on rotation, triangles for libero serves, S in/out and Sx in/out for substitutions), running score (circles for points on serve, triangles for libero serves, slashes for rotation points, closing line through unused numbers), substitution count, timeouts, comments (notes, replays, media timeouts, match result), officials, the scorer's signature once the set is confirmed, and the set result.
- **Exact printing.** One Letter-landscape page per set. Use "Print This Set" or "Print All Sets", then pick a printer or "Save as PDF".
- **Handwriting fonts are embedded**, so the sheet looks the same offline and in print.
- **Fixes:**
  - Rally events now record their set, scoring team, serving team, service slot and libero serve. In v20 these weren't saved, so the running score and service record were blank.
  - A substitution can no longer take the libero off the court, or bring in the player the libero replaced.
  - Undo stops at a confirmed set instead of quietly removing it.
  - Replay records the correct server.
- New optional **Tourney / Event** field in match setup.
- Matches saved by v20 on the same device still render correctly.

## Deploy
Static site: upload `index.html` and `scoresheet-bg.png` together (e.g. to Vercel). No build step.
